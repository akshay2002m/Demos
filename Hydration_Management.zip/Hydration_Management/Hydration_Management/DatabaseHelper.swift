//
//  DatabaseHelper.swift
//  Hydration_Management
//
//  Created by Mac on 16/09/1946 Saka.
//

import Foundation
import CoreData
import UIKit


class CoreDataManager {
    
    static let shared = CoreDataManager()
    private init() {}
    private let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    
    // MARK: SAVE HYDRATION DATA
    func save_Hydration_Data(time: String, date: String, month: String, water: String, uniqueIdentifire: String) {
        let hydrationEntity = NSEntityDescription.entity(forEntityName: "Hydration_Data_Entity", in: context)
        let hydrationData = Hydration_Data_Entity(entity: hydrationEntity!, insertInto: context)
        hydrationData.time = time
        hydrationData.date = date
        hydrationData.month = month
        hydrationData.water = water
        hydrationData.identifire = uniqueIdentifire
        do {
            try context.save()
            print("Hydration data saved successfully")
        } catch {
            print("Failed to save hydration data: \(error.localizedDescription)")
        }
    }
    
    
    
    // MARK: FETCH HYDRATION DATA
    func fetch_Hydration_Data() -> [Hydration_Data_Entity] {
        let fetchRequest: NSFetchRequest<Hydration_Data_Entity> = Hydration_Data_Entity.fetchRequest()
        do {
            print("Fetch hydration data")
            return try context.fetch(fetchRequest)
        } catch {
            print("Failed to fetch hydration data: \(error.localizedDescription)")
            return []
        }
    }
    
    
    // MARK: DELETE HYDRATION DATA
    func delete_Hydration_Data(uniqueIdentifire: String) {
        let fetchRequest: NSFetchRequest<Hydration_Data_Entity> = Hydration_Data_Entity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "identifire == %@", uniqueIdentifire)
        do {
            let results = try context.fetch(fetchRequest)
            
            if let dataToDelete = results.first {
                context.delete(dataToDelete)
                try context.save()
                print("Hydration data with uniqueIdentifire \(uniqueIdentifire) deleted successfully")
            } else {
                print("No hydration data found with uniqueIdentifire: \(uniqueIdentifire)")
            }
        } catch {
            print("Failed to delete hydration data: \(error.localizedDescription)")
        }
    }
    
    
    // MARK: UPDATE HYDRATION DATA
    func update_Hydration_Data(uniqueIdentifire: String, newTime: String?,newWater: String?) {
        let fetchRequest: NSFetchRequest<Hydration_Data_Entity> = Hydration_Data_Entity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "identifire == %@", uniqueIdentifire)
        do {
            let results = try context.fetch(fetchRequest)
            if let hydrationData = results.first {
               
                if let newTime = newTime {
                    hydrationData.time = newTime
                }
                
                if let newWater = newWater {
                    hydrationData.water = newWater
                }
                
                try context.save()
                print("Hydration data with uniqueIde \(uniqueIdentifire) updated successfully")
            } else {
                print("No hydration data found with uniqueIdentifire: \(uniqueIdentifire)")
            }
        } catch {
            print("Failed to update hydration data: \(error.localizedDescription)")
        }
    }

}
