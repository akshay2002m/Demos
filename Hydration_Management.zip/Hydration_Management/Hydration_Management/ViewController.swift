//
//  ViewController.swift
//  Hydration_Management
//
//  Created by Mac on 15/09/1946 Saka.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {
    
    @IBOutlet weak var intakeReminderView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        intakeReminderView.layer.cornerRadius = 10
        intakeReminderView.layer.shadowColor = UIColor.black.cgColor
        intakeReminderView.layer.shadowOpacity = 0.5
        intakeReminderView.layer.shadowOffset = .zero
        intakeReminderView.layer.shadowRadius = 2
        intakeReminderView.layer.masksToBounds = false
        
    }
    
    @IBAction func nextButtonClicked(_ sender: Any) {
        let vc = HydrationViewController(nibName: "HydrationViewController", bundle: nil)
        navigationController?.pushViewController(vc, animated: false)
    }
    
}

