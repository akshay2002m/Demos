//
//  ModelFile.swift
//  Hydration_Management
//
//  Created by Mac on 16/09/1946 Saka.
//

import Foundation

// MARK: MODEL FOR SAVE COREDATA RESPONSE
struct hydration_Data_Model: Codable{
    let time: String?
    let date: String?
    let month: String?
    let water: String?
    let unique_Identifire: String?
}
