//
//  Extentions.swift
//  Hydration_Management
//
//  Created by Mac on 16/09/1946 Saka.
//

import Foundation
import UIKit

func getCurrentTime() -> String {
    let formatter = DateFormatter()
    formatter.dateFormat = "hh:mm:ss a"
    return formatter.string(from: Date())
}


func getCurrentDate() -> String {
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy-MM-dd"
    return formatter.string(from: Date())
}

func getCurrentMonth() -> String {
    let formatter = DateFormatter()
    formatter.dateFormat = "MM"
    return formatter.string(from: Date())
}


func generateRandomString() -> String {
    let characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
    return (0..<10).map { _ in String(characters.randomElement()!) }.joined()
}

extension UIView {
    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        self.layoutIfNeeded()
        let path = UIBezierPath(
            roundedRect: self.bounds,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        self.layer.mask = mask
    }
}



