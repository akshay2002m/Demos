//
//  Hydration_Data_Entity+CoreDataClass.swift
//  Hydration_Management
//
//  Created by Mac on 16/09/1946 Saka.
//
//

import Foundation
import CoreData

@objc(Hydration_Data_Entity)
public class Hydration_Data_Entity: NSManagedObject {

}
