//
//  DrinkingWaterRecordTableViewCell.swift
//  Hydration_Management
//
//  Created by Mac on 16/09/1946 Saka.
//

import UIKit

class DrinkingWaterRecordTableViewCell: UITableViewCell {

    @IBOutlet weak var timeImage: UIImageView!
    @IBOutlet weak var bottleImg: UIImageView!
    @IBOutlet weak var noRecordLabel: UILabel!
    @IBOutlet weak var waterCountLabel: UILabel!
    @IBOutlet weak var intakeTimeLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
}
