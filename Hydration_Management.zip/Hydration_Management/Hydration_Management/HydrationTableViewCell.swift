//
//  HydrationTableViewCell.swift
//  Hydration_Management
//
//  Created by Mac on 15/09/1946 Saka.
//

import UIKit

class HydrationTableViewCell: UITableViewCell {

    @IBOutlet weak var bottleBackgroundView: UIView!
    @IBOutlet weak var fillBottleBackgroundViewHeight: NSLayoutConstraint!
    @IBOutlet weak var addIntakeButton: UIButton!
    @IBOutlet weak var intakeGoalCoveredLabel: UILabel!
    @IBOutlet weak var intakeGoalLabel: UILabel!
    @IBOutlet weak var percentofTargetLabel: UILabel!
    @IBOutlet weak var percentageLabel: UILabel!
    @IBOutlet weak var button100ml: UIButton!
    @IBOutlet weak var button200ml: UIButton!
    @IBOutlet weak var button400ml: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        intakeGoalCoveredLabel.font = UIFont.systemFont(ofSize: 40)
        intakeGoalLabel.font = UIFont.systemFont(ofSize: 18)
        percentofTargetLabel.font = UIFont.systemFont(ofSize: 18)
        addIntakeButton.layer.cornerRadius = 20
        
        let height = bottleBackgroundView.frame.height
        UserDefaults.standard.set(height, forKey: "bottleBackgroundViewHeight")
        
        let intakeGoal = UserDefaults.standard.string(forKey: "manualintake")
        intakeGoalLabel.text = "Water intake goal: \(intakeGoal ?? "2000") ml"
    }
   

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
