//
//  HydrationViewController.swift
//  Hydration_Management
//
//  Created by Mac on 15/09/1946 Saka.
//

import UIKit

class HydrationViewController: UIViewController {
    
    @IBOutlet weak var editIntakeTitleLabel: UILabel!
    @IBOutlet weak var closePopUpButton: UIButton!
    @IBOutlet weak var settingButton: UIButton!
    @IBOutlet weak var hydrationTableView: UITableView!
    @IBOutlet weak var blurBackgroundView: UIView!
    @IBOutlet weak var intakeDataView: UIView!
    @IBOutlet weak var doneButton: UIButton!
    
    @IBOutlet weak var manualIntakeGoalView: UIView!
    @IBOutlet weak var confirmButton: UIButton!
    @IBOutlet weak var manualIntakeGoalViewStackView: UIStackView!
    @IBOutlet weak var setManualIntakeTextField: UITextField!
    @IBOutlet weak var editTimeLabel: UILabel!
    @IBOutlet weak var editTimeButton: UIButton!
    @IBOutlet weak var editInatakeWaterLabel: UILabel!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    var hydration_Data_From_CoreData = [Hydration_Data_Entity]()
    var hydration_Data_Array = [hydration_Data_Model]()
    var coveredPercentage = Int()
    var tempCoveredPercentage = Int()
    var fillBottleViewHeight = Int()
    var isFromAddIntake = false
    let databaseHelper = CoreDataManager.shared
    
    let dateFormatter = DateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setUp()
        
    }
    
    func setUp(){
        
        hydrationTableView.delegate = self
        hydrationTableView.dataSource = self
        
        blurBackgroundView.isHidden = true
        intakeDataView.isHidden = true
        
        intakeDataView.layer.cornerRadius = 10
        intakeDataView.layer.borderWidth = 1
        intakeDataView.layer.borderColor = UIColor.tintColor.cgColor
        
        manualIntakeGoalView.layer.cornerRadius = 10
        manualIntakeGoalView.layer.borderColor = UIColor.tintColor.cgColor
        manualIntakeGoalView.layer.borderWidth = 1
        
        manualIntakeGoalViewStackView.layer.cornerRadius = 10
        manualIntakeGoalViewStackView.layer.borderColor = UIColor.tintColor.cgColor
        manualIntakeGoalViewStackView.layer.borderWidth = 1
        
        confirmButton.layer.cornerRadius = 10
        
        doneButton.layer.cornerRadius = 10
        
        getReloadData()
    }
    
    func getReloadData(){
        
        hydration_Data_From_CoreData.removeAll()
        hydration_Data_Array.removeAll()
        print("BOTH ARRAY'S COUNT AFTER REMOVE:-",hydration_Data_Array.count , hydration_Data_From_CoreData.count)
        
        hydration_Data_From_CoreData = databaseHelper.fetch_Hydration_Data()
        
        for dataFromCoreData in hydration_Data_From_CoreData {
            hydration_Data_Array.append(hydration_Data_Model(time: dataFromCoreData.time, date: dataFromCoreData.date, month: dataFromCoreData.month, water: dataFromCoreData.water, unique_Identifire: dataFromCoreData.identifire))
        }
        print("GET DATA FROM CORE DATA:-",hydration_Data_Array)
        
        print("BOTH ARRAY'S COUNT BEFORE REMOVE:-",hydration_Data_Array.count , hydration_Data_From_CoreData.count)
        
        tempCoveredPercentage = 0
        for i in hydration_Data_Array{
            tempCoveredPercentage += Int(i.water ?? "") ?? 0
        }
        print("TEMP_COVERED WATER PERCENTAGE :-",tempCoveredPercentage)
        
        let targetWaterIntake = UserDefaults.standard.string(forKey: "manualintake")
        coveredPercentage = 0
        coveredPercentage = Int((Double(tempCoveredPercentage) / (Double((targetWaterIntake ?? "")) ?? 0)) * 100)
        coveredPercentage = min(coveredPercentage, 100)
        print("COVERED WATER PERCENTAGE :-",coveredPercentage)
        
        let emptyBottleHeight = UserDefaults.standard.integer(forKey: "bottleBackgroundViewHeight")
        print("EMPTY BOTTLE HEIGHT:-",emptyBottleHeight)
        
        fillBottleViewHeight = coveredPercentage * 2 - 10
        print("FILL BOTTLE HEIGHT:-",fillBottleViewHeight)
        
        let seletedForEditTime = UserDefaults.standard.string(forKey: "selected_Time")
        editTimeLabel.text = seletedForEditTime
        
        let seletedForEditWater = UserDefaults.standard.string(forKey: "selected_Water")
        editInatakeWaterLabel.text = "\(seletedForEditWater ?? "") ml"
        setManualIntakeTextField.text = seletedForEditWater
        
        dateFormatter.dateFormat = "hh:mm:ss a"
        datePicker.datePickerMode = .time
        datePicker.isHidden = true
        
        datePicker.addTarget(self, action: #selector(datePickerChanged), for: .valueChanged)
        
        if isFromAddIntake == true {
            editIntakeTitleLabel.text = "ADD INTAKE"
        }else{
            editIntakeTitleLabel.text = "EDIT INTAKE"
        }
        
        hydrationTableView.reloadData()
    }
    

    @objc func datePickerChanged() {
        let selectedTime = dateFormatter.string(from: datePicker.date)
        UserDefaults.standard.set(selectedTime, forKey: "selected_Time")
        datePicker.isHidden = true
        getReloadData()
        print("Selected time: \(selectedTime)")
    }
    
    @IBAction func backButtonClicked(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    @IBAction func editTimeButtonClicked(_ sender: Any) {
        print("EDIT TIME BUTTON SELECTED")
        datePicker.isHidden = false
    }
    
    @IBAction func editIntakeButtonClicked(_ sender: Any) {
        blurBackgroundView.isHidden = false
        manualIntakeGoalView.isHidden = false
        intakeDataView.isHidden = true
    }
    
    @IBAction func closePopUpButtonClicked(_ sender: Any) {
        blurBackgroundView.isHidden = true
        intakeDataView.isHidden = true
        manualIntakeGoalView.isHidden = true
    }
    @IBAction func intakeDataViewCloseButtonClicked(_ sender: Any) {
        blurBackgroundView.isHidden = true
        intakeDataView.isHidden = true
    }
    
    @IBAction func confirmEditIntakeButtonClicked(_ sender: Any) {
        let editedIntake = setManualIntakeTextField.text
        UserDefaults.standard.set(editedIntake, forKey: "selected_Water")
        if isFromAddIntake == true {
            isFromAddIntake = false
            let currentTime = getCurrentTime()
            let uniqueIdentifire = generateRandomString()
            databaseHelper.save_Hydration_Data(time: currentTime, date: "", month: "", water: editedIntake ?? "", uniqueIdentifire: uniqueIdentifire)
            manualIntakeGoalView.isHidden = true
            intakeDataView.isHidden = true
            blurBackgroundView.isHidden = true
            editIntakeTitleLabel.text = "ADD INTAKE"
        }else{
            editIntakeTitleLabel.text = "EDIT INTAKE"
            manualIntakeGoalView.isHidden = true
            intakeDataView.isHidden = false
        }
        getReloadData()
    }
    
    @IBAction func doneButtonClicked(_ sender: Any) {
        
        let seletedForEditIndex = UserDefaults.standard.string(forKey: "selected_Index") ?? ""
        let seletedForEditTime = UserDefaults.standard.string(forKey: "selected_Time")
        let seletedForEditWater = UserDefaults.standard.string(forKey: "selected_Water")
        
        databaseHelper.update_Hydration_Data(uniqueIdentifire: seletedForEditIndex, newTime: seletedForEditTime, newWater: seletedForEditWater)
        
        blurBackgroundView.isHidden = true
        intakeDataView.isHidden = true
        
        getReloadData()
        
    }
    
    @IBAction func settingButtonClicked(_ sender: Any) {
        let vc = IntakeSettingsViewController(nibName: "IntakeSettingsViewController", bundle: nil)
        navigationController?.pushViewController(vc, animated: false)
    }
    
}

extension HydrationViewController: UITableViewDelegate, UITableViewDataSource {
    
    @objc func button100MlClicked(sender: UIButton){
        let currentTime = getCurrentTime()
        print("100ml button clicked at time: \(currentTime)")
        let currentDate = getCurrentDate()
        print("100ml button clicked at date: \(currentDate)")
        let currentMonth = getCurrentMonth()
        print("100ml button clicked at month: \(currentMonth)")
        let uniqueIdentifire = generateRandomString()
        print("100ml button clicked uniqueIdentifire: \(uniqueIdentifire)")
        
        databaseHelper.save_Hydration_Data(time: currentTime, date: currentDate, month: currentMonth, water: "100", uniqueIdentifire: uniqueIdentifire)
        
        getReloadData()
        
    }
    
    @objc func button200MlClicked(sender: UIButton){
        let currentTime = getCurrentTime()
        print("200ml button clicked at time: \(currentTime)")
        let currentDate = getCurrentDate()
        print("200ml button clicked at date: \(currentDate)")
        let currentMonth = getCurrentMonth()
        print("200ml button clicked at month: \(currentMonth)")
        let uniqueIdentifire = generateRandomString()
        print("200ml button clicked uniqueIdentifire: \(uniqueIdentifire)")
        
        databaseHelper.save_Hydration_Data(time: currentTime, date: currentDate, month: currentMonth, water: "200", uniqueIdentifire: uniqueIdentifire)
        
        getReloadData()
        
    }
    
    @objc func button400MlClicked(sender: UIButton){
        let currentTime = getCurrentTime()
        print("400ml button clicked at time: \(currentTime)")
        let currentDate = getCurrentDate()
        print("400ml button clicked at date: \(currentDate)")
        let currentMonth = getCurrentMonth()
        print("400ml button clicked at month: \(currentMonth)")
        let uniqueIdentifire = generateRandomString()
        print("400ml button clicked uniqueIdentifire: \(uniqueIdentifire)")
        
        databaseHelper.save_Hydration_Data(time: currentTime, date: currentDate, month: currentMonth, water: "400", uniqueIdentifire: uniqueIdentifire)
        
        getReloadData()
        
    }
    
    @objc func addIntakeButtonClicked(sender: UIButton){
        blurBackgroundView.isHidden = false
        manualIntakeGoalView.isHidden = false
        intakeDataView.isHidden = true
        isFromAddIntake = true
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }else{
            return hydration_Data_Array.count
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0 {
            
            hydrationTableView.register(UINib(nibName: "HydrationTableViewCell", bundle: nil), forCellReuseIdentifier: "HydrationCell")
            let hydrationCell = tableView.dequeueReusableCell(withIdentifier: "HydrationCell", for: indexPath) as! HydrationTableViewCell
            hydrationCell.selectionStyle = .none
            
           
            
            hydrationCell.intakeGoalCoveredLabel.text = "\(tempCoveredPercentage)"
            hydrationCell.percentageLabel.text = "\(coveredPercentage) %"
            hydrationCell.percentofTargetLabel.text = "Intake : \(coveredPercentage)% of the target"
            hydrationCell.fillBottleBackgroundViewHeight.constant = CGFloat(fillBottleViewHeight)
            
            hydrationCell.button100ml.addTarget(self, action: #selector(button100MlClicked(sender:)), for: .touchUpInside)
            hydrationCell.button200ml.addTarget(self, action: #selector(button200MlClicked(sender:)), for: .touchUpInside)
            hydrationCell.button400ml.addTarget(self, action: #selector(button400MlClicked(sender:)), for: .touchUpInside)
            hydrationCell.addIntakeButton.addTarget(self, action: #selector(addIntakeButtonClicked(sender:)), for: .touchUpInside)
            
            
            return hydrationCell
            
        }else{
            
            hydrationTableView.register(UINib(nibName: "DrinkingWaterRecordTableViewCell", bundle: nil), forCellReuseIdentifier: "RecordCell")
            let drinkingWaterCell = tableView.dequeueReusableCell(withIdentifier: "RecordCell", for: indexPath) as! DrinkingWaterRecordTableViewCell
            drinkingWaterCell.selectionStyle = .none
            
            if hydration_Data_Array.isEmpty == true{
                drinkingWaterCell.noRecordLabel.isHidden = false
                drinkingWaterCell.bottleImg.isHidden = true
                drinkingWaterCell.timeImage.isHidden = true
                drinkingWaterCell.intakeTimeLabel.isHidden = true
                drinkingWaterCell.waterCountLabel.isHidden = true
            }else{
                drinkingWaterCell.noRecordLabel.isHidden = true
                drinkingWaterCell.bottleImg.isHidden = false
                drinkingWaterCell.timeImage.isHidden = false
                drinkingWaterCell.intakeTimeLabel.isHidden = false
                drinkingWaterCell.waterCountLabel.isHidden = false
            let drinkingWaterData = hydration_Data_Array[indexPath.row]
            drinkingWaterCell.waterCountLabel.text = "\(drinkingWaterData.water ?? "")ml"
            drinkingWaterCell.intakeTimeLabel.text = drinkingWaterData.time
            
            }
            return drinkingWaterCell
            
        }
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let deleteAction = UITableViewRowAction(style: .destructive, title: "DELETE") { [weak self] action, indexPath in
            let uniqueIdentifire = self?.hydration_Data_Array[indexPath.row].unique_Identifire ?? ""
            print("DELETE BUTTON CLICKED:-", uniqueIdentifire)
            let alertController = UIAlertController(
                title: "Confirm Deletion",
                message: "Are you sure you want to permanently delete this item?",
                preferredStyle: .alert
            )
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { _ in
                print("Deletion cancelled")
            }
            let deleteConfirmationAction = UIAlertAction(title: "Delete", style: .destructive) { _ in
                self?.databaseHelper.delete_Hydration_Data(uniqueIdentifire: uniqueIdentifire)
                self?.getReloadData()
            }
            alertController.addAction(cancelAction)
            alertController.addAction(deleteConfirmationAction)
            self?.present(alertController, animated: true, completion: nil)
        }

        
        let editAction = UITableViewRowAction(style: .normal, title: "EDIT") { [self] action, indexPath in
            
            let selectedIndex = hydration_Data_Array[indexPath.row].unique_Identifire
            UserDefaults.standard.set(selectedIndex, forKey: "selected_Index")
            
            let selectedTime = hydration_Data_Array[indexPath.row].time
            UserDefaults.standard.set(selectedTime, forKey: "selected_Time")
            
            let selectedWater = hydration_Data_Array[indexPath.row].water
            UserDefaults.standard.set(selectedWater, forKey: "selected_Water")
            
            blurBackgroundView.isHidden = false
            intakeDataView.isHidden = false
            
            getReloadData()
        }
        editAction.backgroundColor = .blue
        
        return [editAction, deleteAction]
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}
