
//
//  IntakeSettingsViewController.swift
//  Hydration_Management
//
//  Created by Mac on 15/09/1946 Saka.
//

import UIKit
import UserNotifications

class IntakeSettingsViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var intakeReminderSwitchButton: UISwitch!
    @IBOutlet weak var timerView: UIView!
    @IBOutlet weak var timerViewHeight: NSLayoutConstraint!
    @IBOutlet weak var timePickerButton: UIButton!
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var staringTimeLabel: UILabel!
    @IBOutlet weak var timePickerBackgroundView: UIView!
    @IBOutlet weak var reminderTimesTextField: UITextField!
    @IBOutlet weak var intervalTimeTextField: UITextField!
    @IBOutlet weak var popBlurButton: UIView!

    @IBOutlet weak var manualIntakeGoalView: UIView!
    @IBOutlet weak var confirmButton: UIButton!
    @IBOutlet weak var manualIntakeGoalViewStackView: UIStackView!
    @IBOutlet weak var setManualIntakeTextField: UITextField!
    @IBOutlet weak var intakeGoalLabel: UILabel!
    
    @IBOutlet weak var addPromptTextViewBgView: UIView!
    @IBOutlet weak var addPromptView: UIView!
    @IBOutlet weak var addPromptTextView: UITextView!
    @IBOutlet weak var addPromptCancleButton: UIButton!
    @IBOutlet weak var addPromptSaveButton: UIButton!
    @IBOutlet weak var promptLabel: UILabel!
    @IBOutlet weak var addPromptButton: UIButton!
    
    let dateFormatter = DateFormatter()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        reloadData()
    }
    
    
    func reloadData(){
        
        let isSelection = UserDefaults.standard.bool(forKey: "isReminderToggleOpen")
        print("ISSELECTION:=",isSelection)
        if isSelection == true {
            intakeReminderSwitchButton.isOn = true
            print("Switch is ON")
            timerViewHeight.constant = 237
            timerView.isHidden = false
            requestNotificationPermission()
            let selectedTime = UserDefaults.standard.string(forKey: "selectedtime") ?? ""
            scheduleNotifications(startTimeString: selectedTime)
        }else if isSelection == false{
            intakeReminderSwitchButton.isOn = false
            print("Switch is OFF")
            timerViewHeight.constant = 0
            timerView.isHidden = true
        }
        
        timePickerBackgroundView.layer.cornerRadius = 10
        timePickerBackgroundView.layer.borderColor = UIColor.tintColor.cgColor
        timePickerBackgroundView.layer.borderWidth = 1.5
        
        reminderTimesTextField.layer.cornerRadius = 10
        reminderTimesTextField.layer.borderColor = UIColor.tintColor.cgColor
        reminderTimesTextField.layer.borderWidth = 1.5
        
        intervalTimeTextField.layer.cornerRadius = 10
        intervalTimeTextField.layer.borderColor = UIColor.tintColor.cgColor
        intervalTimeTextField.layer.borderWidth = 1.5
        
        manualIntakeGoalView.layer.cornerRadius = 10
        manualIntakeGoalView.layer.borderColor = UIColor.tintColor.cgColor
        manualIntakeGoalView.layer.borderWidth = 1
        
        manualIntakeGoalViewStackView.layer.cornerRadius = 10
        manualIntakeGoalViewStackView.layer.borderColor = UIColor.tintColor.cgColor
        manualIntakeGoalViewStackView.layer.borderWidth = 1
        
        addPromptView.layer.cornerRadius = 10
        addPromptView.layer.borderColor = UIColor.tintColor.cgColor
        addPromptView.layer.borderWidth = 1.5
        
        addPromptCancleButton.layer.cornerRadius = 10
        addPromptCancleButton.layer.borderColor = UIColor.tintColor.cgColor
        addPromptCancleButton.layer.borderWidth = 1
        
        addPromptTextViewBgView.layer.cornerRadius = 10
        addPromptTextViewBgView.layer.borderColor = UIColor.tintColor.cgColor
        addPromptTextViewBgView.layer.borderWidth = 1
        
        addPromptSaveButton.layer.cornerRadius = 10
        
        confirmButton.layer.cornerRadius = 10
        
        dateFormatter.dateFormat = "hh:mm:ss a"
        datePicker.datePickerMode = .time
        datePicker.isHidden = true

        let selectedTime = UserDefaults.standard.string(forKey: "selectedtime")
        staringTimeLabel.text = selectedTime ?? "Select Time"
        
        datePicker.addTarget(self, action: #selector(datePickerChanged), for: .valueChanged)
        
        let intakeGoal = UserDefaults.standard.string(forKey: "manualintake")
        intakeGoalLabel.text = "\(intakeGoal ?? "2000") ml"
        
        setManualIntakeTextField.text = intakeGoal ?? "2000"
        
        let promptText = UserDefaults.standard.string(forKey: "prompttext")
        addPromptTextView.text = promptText ?? "Add prompt!"
        promptLabel.text = promptText ?? "Add prompt!"
        
        reminderTimesTextField.delegate = self
        intervalTimeTextField.delegate = self
        
        let reminderTimes = UserDefaults.standard.string(forKey: "reminderTimes")
        print("REMINDER TIME FROM USERDEFAULT: \(reminderTimes ?? "10")")
        reminderTimesTextField.text = reminderTimes ?? ""
        
        let intervalTime = UserDefaults.standard.string(forKey: "intervalTime")
        print("INTERVAL TIME FROM USERDEFAULT: \(intervalTime ?? "30")")
        intervalTimeTextField.text = intervalTime ?? ""
        
    }
    
    func textFieldDidChangeSelection(_ textField: UITextField) {
        if textField == reminderTimesTextField {
            if let reminderText = reminderTimesTextField.text, !reminderText.isEmpty {
                print("Reminder time entered: \(reminderText)")
                UserDefaults.standard.set("", forKey: "reminderTimes")
                UserDefaults.standard.set(reminderText, forKey: "reminderTimes")
            }
        } else if textField == intervalTimeTextField {
            if let intervalText = intervalTimeTextField.text, !intervalText.isEmpty {
                print("Interval time entered: \(intervalText)")
                UserDefaults.standard.set("", forKey: "intervalTime")
                UserDefaults.standard.set(intervalText, forKey: "intervalTime")
            }
        }
    }

    
    @IBAction func backButtonClicked(_ sender: Any) {
        navigationController?.popViewController(animated: false)
    }
    
    @IBAction func addPromptButtonClicked(_ sender: Any) {
        addPromptView.isHidden = false
        popBlurButton.isHidden = false
        print("ADD PROMPT BUTTON CLICKED")
    }
    
    @IBAction func addPromptCancleButtonClicked(_ sender: Any) {
        addPromptView.isHidden = true
        popBlurButton.isHidden = true
    }
    
    @IBAction func addPromptSaveButtonClicked(_ sender: Any) {
        addPromptView.isHidden = true
        popBlurButton.isHidden = true
        let promptText = addPromptTextView.text
        UserDefaults.standard.set(promptText, forKey: "prompttext")
        reloadData()
    }
    
    @IBAction func addManualIntakeGoalViewButtonClicked(_ sender: Any) {
        popBlurButton.isHidden = false
        manualIntakeGoalView.isHidden = false
    }
    
    @IBAction func confirmButtonClicked(_ sender: Any) {
        popBlurButton.isHidden = true
        manualIntakeGoalView.isHidden = true
        let manualIntake = setManualIntakeTextField.text
        UserDefaults.standard.set(manualIntake, forKey: "manualintake")
        reloadData()
    }
    
    @IBAction func popBlurButtonClicked(_ sender: Any) {
        popBlurButton.isHidden = true
        manualIntakeGoalView.isHidden = true
    }
    
    @IBAction func intakeReminderSwitchButtonClicked(_ sender: UISwitch) {
        if sender.isOn == true{
            UserDefaults.standard.set(true, forKey: "isReminderToggleOpen")
            print("TRUE SET KELAY")
        } else if sender.isOn == false{
            print("FALSE SET KELAY")
            UserDefaults.standard.set(false, forKey: "isReminderToggleOpen")
        }
        reloadData()
    }

    
    @IBAction func timePickerButtonClicked(_ sender: Any) {
        datePicker.isHidden = false
    }

    @objc func datePickerChanged() {
        let selectedTime = dateFormatter.string(from: datePicker.date)
        UserDefaults.standard.set(selectedTime, forKey: "selectedtime")
        datePicker.isHidden = true
        reloadData()
        print("Selected time: \(selectedTime)")
    }
    
    
    
    func requestNotificationPermission() {
            let center = UNUserNotificationCenter.current()
            center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
                if granted {
                    print("Notification permission granted.")
                } else {
                    print("Notification permission denied.")
                }
            }
        }
    
        func scheduleNotifications(startTimeString: String) {
            let center = UNUserNotificationCenter.current()
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "hh:mm a"
            
            guard let startDate = dateFormatter.date(from: startTimeString) else {
                print("Error parsing time string.")
                return
            }
            
            let now = Date()
            let calendar = Calendar.current
            let adjustedStartDate: Date
            
            if startDate < now {
                adjustedStartDate = calendar.date(byAdding: .day, value: 1, to: startDate)!
            } else {
                adjustedStartDate = startDate
            }
            let triggerTimes = UserDefaults.standard.string(forKey: "reminderTimes")
            let triggerTimes2 = Int(triggerTimes ?? "") ?? 0
            for i in 0..<triggerTimes2 {
                let content = UNMutableNotificationContent()
                content.title = "Reminder"
                let promptText = UserDefaults.standard.string(forKey: "prompttext") ?? ""
                content.body = promptText
                content.sound = .default

//                let intervalTime = 1
                let intervalTime = UserDefaults.standard.string(forKey: "intervalTime") ?? ""
                let intervalTime2 = Int(intervalTime) ?? 0
                let triggerDate = calendar.date(byAdding: .minute, value: i * intervalTime2, to: adjustedStartDate)!
                let triggerComponents = calendar.dateComponents([.hour, .minute, .second], from: triggerDate)
                
                let trigger = UNCalendarNotificationTrigger(dateMatching: triggerComponents, repeats: false)
                
                let request = UNNotificationRequest(identifier: "hydrationReminder\(i)", content: content, trigger: trigger)
                
                center.add(request) { error in
                    if let error = error {
                        print("Error scheduling notification: \(error.localizedDescription)")
                    }
                }
            }
        }
        
}
