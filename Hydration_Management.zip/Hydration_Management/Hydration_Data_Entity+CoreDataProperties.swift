//
//  Hydration_Data_Entity+CoreDataProperties.swift
//  Hydration_Management
//
//  Created by Mac on 16/09/1946 Saka.
//
//

import Foundation
import CoreData


extension Hydration_Data_Entity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Hydration_Data_Entity> {
        return NSFetchRequest<Hydration_Data_Entity>(entityName: "Hydration_Data_Entity")
    }

    @NSManaged public var time: String?
    @NSManaged public var date: String?
    @NSManaged public var month: String?
    @NSManaged public var water: String?
    @NSManaged public var identifire: String?
    

}

extension Hydration_Data_Entity : Identifiable {

}
